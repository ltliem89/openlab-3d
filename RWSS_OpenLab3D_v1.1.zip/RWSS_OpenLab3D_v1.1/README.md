# RWSS v1.1 — OpenLab 3D

Bộ tiêu chuẩn được thiết kế lại theo báo cáo rà soát chức năng thực tế của OpenLab 3D.

## Nội dung gói

1. `01_ENVIRONMENT_LAYER.md` — không gian, bề mặt, ray, chất lỏng, ánh sáng, nhiệt và điều kiện môi trường.
2. `02_OBJECT_LAYER.md` — hồ sơ thiết bị, mẫu vật, hình học, thuộc tính, cổng kết nối và registry.
3. `03_INTERACTION_LAYER.md` — docking, lắp ráp, đo lường, chất lỏng, nhiệt, điện, quang học, cảm ứng và kiểm thử.
4. `04_OPENLAB_OPERATION_COMMAND.md` — prompt điều hành AI coding agent, lệnh tiếp tục và lệnh release audit.

## Cách dùng

- Đưa ba file lớp vào `docs/standards/RWSS/` của repository OpenLab.
- Đưa báo cáo rà soát gốc vào vị trí tài liệu dự án mà AI coding agent có thể đọc.
- Dùng lệnh trong `04_OPENLAB_OPERATION_COMMAND.md`.
- Yêu cầu AI audit code và lập compliance matrix trước khi sửa.
- Triển khai từng gap nhỏ, chạy test và giữ regression.

## Phạm vi và giới hạn

Bộ tiêu chuẩn dựa trên những hành vi được mô tả trong báo cáo rà soát. Đây không phải xác nhận độc lập rằng toàn bộ mã nguồn hiện tại vẫn có các hành vi đó. AI coding agent phải kiểm tra code đang có trước khi sửa. Những tham số không có nguồn phải giữ trạng thái chưa xác minh.
